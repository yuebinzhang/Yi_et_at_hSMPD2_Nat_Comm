#awk '{if($1=="ATOM") print $11}' ../step5_assembly.pdb|uniq

for i in PROA PROB HETC HETD LSMA LSMB MEMB WAT1 WAT2 WAT3 WAT4 WAT5 WAT6 MG CLA
do
	grep $i ../frame198.pdb > $i.pdb
done
